﻿using System;
using System.Speech.Recognition;
using System.Threading;
using WindowsInput;
using WindowsInput.Native;

class Program
{
    static ManualResetEvent manualResetEvent = null;

    static void Main()
    {
        manualResetEvent = new ManualResetEvent(false);
        InputSimulator sim = new InputSimulator();

        using (SpeechRecognitionEngine recognizer = new SpeechRecognitionEngine())
        {
            Grammar dictationGrammar = new DictationGrammar();
            recognizer.LoadGrammar(dictationGrammar);

            recognizer.SpeechRecognized += Recognizer_SpeechRecognized;
            recognizer.RecognizeCompleted += Recognizer_RecognizeCompleted;

            recognizer.SetInputToDefaultAudioDevice();

            recognizer.RecognizeAsync(RecognizeMode.Multiple);

            Console.WriteLine("Speak into your microphone. Say 'exit' to end the program.");

            manualResetEvent.WaitOne();
        }
    }

    static void Recognizer_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
    {
        Console.WriteLine($"Recognized text: {e.Result.Text}");

        if (e.Result.Text.Equals("exit", StringComparison.OrdinalIgnoreCase))
        {
            manualResetEvent.Set();
        }

        CheckWord(e.Result.Text, new InputSimulator());
    }

    static void Recognizer_RecognizeCompleted(object sender, RecognizeCompletedEventArgs e)
    {
        Console.WriteLine("Recognition completed.");
    }

    static void CheckWord(string word, InputSimulator sim)
    {
        sim.Keyboard.TextEntry(word);
    }
}
